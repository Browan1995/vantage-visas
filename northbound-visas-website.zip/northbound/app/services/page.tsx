import { SERVICES, SITE } from '@/lib/config';
import Reveal from '@/components/Reveal';
import Link from 'next/link';

export const metadata = {
  title: 'Services & Pricing — Northbound Visas',
  description: 'Transparent pricing for USA, UK, Schengen and Canada visa applications.',
};

export default function ServicesPage() {
  return (
    <>
      {/* HERO */}
      <section className="relative pt-40 pb-20 stars-bg">
        <div className="max-w-7xl mx-auto px-6">
          <Reveal>
            <span className="gold-divider mb-6">Services & Pricing</span>
            <h1 className="font-display text-5xl md:text-7xl font-bold mt-6 mb-6 max-w-4xl">
              Transparent <span className="gold-text italic">pricing.</span>
              <br />No surprises.
            </h1>
            <p className="text-white/70 text-lg max-w-2xl">
              Every Northbound service includes full preparation, document
              review, interview coaching where applicable, and ongoing
              WhatsApp support. Government fees are paid separately to the
              relevant embassy or consulate.
            </p>
          </Reveal>
        </div>
      </section>

      {/* SERVICES LIST */}
      <section className="pb-24 max-w-7xl mx-auto px-6">
        <div className="space-y-8">
          {SERVICES.map((s, i) => (
            <Reveal key={s.id} delay={i * 60}>
              <div
                id={s.id}
                className="bg-navy-light/50 border border-gold/20 hover:border-gold/50 rounded-lg overflow-hidden transition-colors scroll-mt-32"
              >
                <div className="grid lg:grid-cols-5 gap-0">
                  <div className="lg:col-span-2 relative aspect-[16/10] lg:aspect-auto overflow-hidden">
                    <img
                      src={s.image}
                      alt={s.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-r from-navy/60 via-transparent to-transparent" />
                  </div>
                  <div className="lg:col-span-3 p-8 md:p-12">
                    <div className="flex flex-wrap items-start justify-between gap-4 mb-4">
                      <div>
                        <div className="text-xs text-gold uppercase tracking-widest mb-2">
                          {s.subtitle}
                        </div>
                        <h2 className="font-display text-3xl md:text-4xl font-bold">
                          {s.title}
                        </h2>
                      </div>
                      <div className="bg-gold text-navy px-5 py-2 rounded font-bold text-xl">
                        {s.price}
                      </div>
                    </div>
                    <p className="text-white/70 leading-relaxed mb-6">
                      {s.description}
                    </p>
                    <ul className="space-y-2.5 mb-8">
                      {s.features.map((f) => (
                        <li
                          key={f}
                          className="flex items-start gap-3 text-white/70 text-sm"
                        >
                          <span className="text-gold mt-0.5">✓</span>
                          {f}
                        </li>
                      ))}
                    </ul>
                    <a
                      href={`https://wa.me/${SITE.whatsapp}?text=${encodeURIComponent(
                        `Hi! I'd like to apply for the ${s.title} visa with Northbound Visas.`
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="btn-emerald"
                    >
                      Apply via WhatsApp
                    </a>
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* DISCLAIMER */}
      <section className="pb-24 max-w-4xl mx-auto px-6">
        <Reveal>
          <div className="bg-navy-light/40 border-l-4 border-gold rounded p-6 text-sm text-white/60 leading-relaxed">
            <strong className="text-gold">Important:</strong> Prices listed are
            for Northbound Visas consultancy services only. Government
            application fees (MRV, SEVIS, IHS, biometric, etc.) are paid
            separately by the client directly to the relevant authority.
            Northbound Visas cannot guarantee visa outcomes — the final decision
            is always made by a consular officer. We commit to preparing your
            application to the highest standard of accuracy and completeness.
          </div>
        </Reveal>
      </section>
    </>
  );
}

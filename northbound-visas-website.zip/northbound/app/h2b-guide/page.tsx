import { SITE } from '@/lib/config';
import Reveal from '@/components/Reveal';
import Link from 'next/link';

export const metadata = {
  title: 'H-2B Visa Guide — Northbound Visas',
  description: 'Complete guide to the US H-2B temporary non-agricultural worker visa process for South Africans.',
};

const STEPS = [
  {
    n: '01',
    title: 'Confirm a Bona Fide US Employer',
    body: 'The US employer must be a registered business with a valid Federal Employer Identification Number (FEIN), physically located in the United States. A private individual offering you cash work cannot petition for an H-2B visa. Before any fees change hands, we verify the employer is real, registered, and able to sponsor.',
  },
  {
    n: '02',
    title: 'Department of Labor Temporary Labor Certification',
    body: 'The employer files an Application for Temporary Employment Certification with the US Department of Labor through the FLAG portal. They must demonstrate that the need is genuinely temporary (seasonal, peak-load, intermittent, or one-time), recruit US workers first through the State Workforce Agency, and commit to paying at least the prevailing wage. This stage typically takes 60–90 days.',
  },
  {
    n: '03',
    title: 'USCIS Petition (Form I-129)',
    body: 'Once the labor certification is approved, the employer files Form I-129 with USCIS, attaching the original DOL certification. The employer pays all filing fees — under US law, charging the worker for these is illegal. USCIS adjudicates the petition and, if approved, issues Form I-797 (Notice of Action). Without an approved I-797, no visa application can proceed.',
  },
  {
    n: '04',
    title: 'DS-160 & Consular Interview',
    body: 'With the I-797 in hand, you complete the DS-160 online application, pay the MRV fee, and book a consular interview. We prepare your full document file, conduct mock interviews, and brief you on what to expect. The interview is the critical step — accurate, confident answers and complete documentation matter.',
  },
  {
    n: '05',
    title: 'Visa Issuance & Travel',
    body: 'If approved, your passport is returned with the H-2B visa stamp. You may enter the United States no earlier than 10 days before your employment start date. At the port of entry, a CBP officer makes the final admission decision and issues your I-94 record.',
  },
];

const FACTS = [
  { label: 'Annual Cap', value: '66,000' },
  { label: 'Visa Validity', value: 'Up to 1 Year' },
  { label: 'Max Stay', value: '3 Years Total' },
  { label: 'Family Visas', value: 'H-4 (No Work)' },
];

export default function H2BGuidePage() {
  return (
    <>
      {/* HERO */}
      <section className="relative pt-40 pb-20 stars-bg overflow-hidden">
        <div
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage:
              'url(https://images.unsplash.com/photo-1560748952-1d2d768c2337?w=1800&q=80)',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-navy via-navy/90 to-navy" />
        <div className="relative max-w-7xl mx-auto px-6">
          <Reveal>
            <span className="gold-divider mb-6">USA Specialised</span>
            <h1 className="font-display text-5xl md:text-7xl font-bold mt-6 mb-6 max-w-4xl">
              H-2B <span className="gold-text italic">Visa Guide.</span>
            </h1>
            <p className="text-white/70 text-lg max-w-3xl leading-relaxed">
              The complete, honest guide to the United States H-2B temporary
              non-agricultural worker visa for South African applicants. Read
              this before you pay anyone — including us.
            </p>
          </Reveal>
        </div>
      </section>

      {/* QUICK FACTS */}
      <section className="py-12 max-w-7xl mx-auto px-6">
        <Reveal>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {FACTS.map((f) => (
              <div
                key={f.label}
                className="bg-navy-light/50 border border-gold/20 rounded-lg p-6 text-center"
              >
                <div className="font-display text-3xl md:text-4xl gold-text font-bold mb-1">
                  {f.value}
                </div>
                <div className="text-xs text-white/60 uppercase tracking-widest">
                  {f.label}
                </div>
              </div>
            ))}
          </div>
        </Reveal>
      </section>

      {/* WHAT IS H-2B */}
      <section className="py-16 max-w-4xl mx-auto px-6">
        <Reveal>
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-6">
            What is the <span className="gold-text italic">H-2B?</span>
          </h2>
          <div className="space-y-4 text-white/70 leading-relaxed">
            <p>
              The H-2B visa allows US employers to hire foreign nationals for
              temporary, non-agricultural jobs that they cannot fill with
              American workers. It is most commonly used in hospitality,
              landscaping, seafood processing, ski resorts, amusement parks,
              construction and similar seasonal industries.
            </p>
            <p>
              South Africa is on the list of H-2B eligible countries, and as of
              January 2025 USCIS no longer requires the beneficiary to be from
              a designated country at all — so nationality is not a barrier.
              What matters is having a real US employer willing and able to
              sponsor you.
            </p>
            <p className="text-gold font-medium">
              The H-2B is a non-immigrant, employer-sponsored visa. You cannot
              apply for it on your own. The employer must initiate the entire
              process and pay the filing fees.
            </p>
          </div>
        </Reveal>
      </section>

      {/* PROCESS STEPS */}
      <section className="py-16 bg-navy-light/30 border-y border-gold/15">
        <div className="max-w-5xl mx-auto px-6">
          <Reveal>
            <div className="text-center mb-16">
              <span className="gold-divider mb-6">The Process</span>
              <h2 className="font-display text-4xl md:text-5xl font-bold mt-6">
                Five steps from <span className="gold-text italic">start to stamp.</span>
              </h2>
            </div>
          </Reveal>
          <div className="space-y-6">
            {STEPS.map((s, i) => (
              <Reveal key={s.n} delay={i * 80}>
                <div className="bg-navy border border-gold/20 hover:border-gold/50 rounded-lg p-8 md:p-10 transition-colors">
                  <div className="flex items-start gap-6">
                    <div className="font-display text-5xl gold-text font-bold leading-none flex-shrink-0">
                      {s.n}
                    </div>
                    <div>
                      <h3 className="font-display text-2xl md:text-3xl font-bold mb-3 text-gold">
                        {s.title}
                      </h3>
                      <p className="text-white/70 leading-relaxed">{s.body}</p>
                    </div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* THIRD COUNTRY PROCESSING */}
      <section className="py-20 max-w-4xl mx-auto px-6">
        <Reveal>
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-6">
            Third-country <span className="gold-text italic">processing.</span>
          </h2>
          <div className="space-y-4 text-white/70 leading-relaxed">
            <p>
              Some applicants ask whether they can interview at a US consulate
              in a third country — for example Brazil — instead of South
              Africa. This is technically possible but generally <em>harder</em>,
              not easier.
            </p>
            <p>
              Consular officers are trained to adjudicate applicants from the
              local pool. A South African walking into a Brazilian post is an
              unusual case, and the officer has less ability to verify your
              ties to a country they don't cover. Wait times and acceptance of
              third-country nationals vary significantly between posts, and an
              applicant who skips their home consulate can be perceived as
              "shopping" for a yes.
            </p>
            <p>
              For most South Africans the home consulate (Johannesburg) is the
              right answer. Third-country processing only makes practical sense
              if you actually live, work or study legally in that country.
              We'll give you a straight answer about which post is best for
              your specific case.
            </p>
          </div>
        </Reveal>
      </section>

      {/* WARNINGS */}
      <section className="pb-24 max-w-4xl mx-auto px-6">
        <Reveal>
          <div className="bg-red-950/30 border-l-4 border-red-500 rounded p-8">
            <h3 className="font-display text-2xl font-bold text-red-300 mb-4">
              ⚠ Watch out for these red flags
            </h3>
            <ul className="space-y-3 text-white/70 text-sm">
              <li>
                <strong className="text-white">"Recruiter" wants payment from you.</strong>{' '}
                Charging workers for H-2B placement is illegal under US law. If
                anyone — recruiter, agent, "sponsor" — asks you for fees, walk
                away.
              </li>
              <li>
                <strong className="text-white">No registered US business.</strong>{' '}
                The employer must have a valid FEIN. A friend offering cash
                work is not an H-2B employer.
              </li>
              <li>
                <strong className="text-white">"Guaranteed approval."</strong> No
                one — not us, not anyone — can guarantee a visa outcome. Anyone
                who says they can is lying.
              </li>
              <li>
                <strong className="text-white">Pressure to apply immediately.</strong>{' '}
                The H-2B process is bound to a 66,000 annual cap and seasonal
                filing windows. Honest agents explain timing realistically.
              </li>
            </ul>
          </div>
        </Reveal>
      </section>

      {/* CTA */}
      <section className="pb-24 max-w-4xl mx-auto px-6 text-center">
        <Reveal>
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-6">
            Have an H-2B job offer?
          </h2>
          <p className="text-white/70 mb-8 max-w-2xl mx-auto">
            Send us the employer details and the I-797 number. We'll verify
            everything and tell you honestly whether the application can proceed.
          </p>
          <a
            href={`https://wa.me/${SITE.whatsapp}?text=${encodeURIComponent(
              "Hi! I have an H-2B job offer in the US and need help with the visa process."
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-emerald"
          >
            Discuss My Case on WhatsApp
          </a>
        </Reveal>
      </section>
    </>
  );
}

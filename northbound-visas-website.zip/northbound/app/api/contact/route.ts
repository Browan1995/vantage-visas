import { NextResponse } from 'next/server';
import { Resend } from 'resend';

export async function POST(req: Request) {
  try {
    const { name, phone, email, destination, message } = await req.json();

    if (!name || !email || !phone) {
      return NextResponse.json(
        { error: 'Name, email and phone are required' },
        { status: 400 }
      );
    }

    const apiKey = process.env.RESEND_API_KEY;
    const toEmail = process.env.CONTACT_TO_EMAIL || 'rowanvdmerwe@gmail.com';
    const fromEmail = process.env.CONTACT_FROM_EMAIL || 'onboarding@resend.dev';

    if (!apiKey) {
      console.error('RESEND_API_KEY not set');
      return NextResponse.json(
        { error: 'Email service not configured. Please set RESEND_API_KEY in Vercel.' },
        { status: 500 }
      );
    }

    const resend = new Resend(apiKey);

    const html = `
      <div style="font-family: Inter, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #0B1A33; padding: 24px; border-bottom: 3px solid #C9A961;">
          <h1 style="color: #C9A961; margin: 0; font-size: 22px;">New Application — Northbound Visas</h1>
        </div>
        <div style="padding: 24px; background: #FAF8F3;">
          <table style="width: 100%; border-collapse: collapse;">
            <tr><td style="padding: 8px 0; color: #6B7280; font-size: 12px; text-transform: uppercase; letter-spacing: 1px;">Name</td></tr>
            <tr><td style="padding: 0 0 16px; color: #0B1A33; font-size: 16px; font-weight: 600;">${escape(name)}</td></tr>
            <tr><td style="padding: 8px 0; color: #6B7280; font-size: 12px; text-transform: uppercase; letter-spacing: 1px;">Phone</td></tr>
            <tr><td style="padding: 0 0 16px; color: #0B1A33; font-size: 16px;"><a href="tel:${escape(phone)}" style="color: #0B1A33;">${escape(phone)}</a></td></tr>
            <tr><td style="padding: 8px 0; color: #6B7280; font-size: 12px; text-transform: uppercase; letter-spacing: 1px;">Email</td></tr>
            <tr><td style="padding: 0 0 16px; color: #0B1A33; font-size: 16px;"><a href="mailto:${escape(email)}" style="color: #0B1A33;">${escape(email)}</a></td></tr>
            <tr><td style="padding: 8px 0; color: #6B7280; font-size: 12px; text-transform: uppercase; letter-spacing: 1px;">Destination</td></tr>
            <tr><td style="padding: 0 0 16px; color: #0B1A33; font-size: 16px; font-weight: 600;">${escape(destination || 'Not specified')}</td></tr>
            ${message ? `
              <tr><td style="padding: 8px 0; color: #6B7280; font-size: 12px; text-transform: uppercase; letter-spacing: 1px;">Message</td></tr>
              <tr><td style="padding: 0; color: #0B1A33; font-size: 14px; line-height: 1.6; white-space: pre-wrap;">${escape(message)}</td></tr>
            ` : ''}
          </table>
        </div>
        <div style="padding: 16px 24px; background: #0B1A33; color: rgba(255,255,255,0.5); font-size: 11px; text-align: center;">
          Sent from northboundvisas.co.za contact form
        </div>
      </div>
    `;

    const { error } = await resend.emails.send({
      from: `Northbound Visas <${fromEmail}>`,
      to: [toEmail],
      replyTo: email,
      subject: `New ${destination || 'visa'} application — ${name}`,
      html,
    });

    if (error) {
      console.error('Resend error:', error);
      return NextResponse.json({ error: 'Failed to send email' }, { status: 500 });
    }

    return NextResponse.json({ ok: true });
  } catch (err: any) {
    console.error('Contact API error:', err);
    return NextResponse.json(
      { error: err.message || 'Internal error' },
      { status: 500 }
    );
  }
}

function escape(s: string): string {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

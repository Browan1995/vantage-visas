import { SITE, TRUST_POINTS } from '@/lib/config';
import Reveal from '@/components/Reveal';
import Link from 'next/link';

export const metadata = {
  title: 'About — Northbound Visas',
  description: 'Our mission to simplify global travel for South Africans.',
};

export default function AboutPage() {
  return (
    <>
      {/* HERO */}
      <section className="relative pt-40 pb-20 stars-bg overflow-hidden">
        <div
          className="absolute inset-0 opacity-15"
          style={{
            backgroundImage:
              'url(https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=1800&q=80)',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-navy/80 via-navy/95 to-navy" />
        <div className="relative max-w-7xl mx-auto px-6">
          <Reveal>
            <span className="gold-divider mb-6">About Us</span>
            <h1 className="font-display text-5xl md:text-7xl font-bold mt-6 mb-6 max-w-4xl">
              Helping South Africans
              <br />
              <span className="gold-text italic">go further.</span>
            </h1>
          </Reveal>
        </div>
      </section>

      {/* MISSION */}
      <section className="py-20 max-w-4xl mx-auto px-6">
        <Reveal>
          <div className="space-y-6 text-white/70 leading-relaxed text-lg">
            <p>
              Northbound Visas was founded on a simple frustration: getting a
              visa as a South African is harder than it should be, and the
              advice you find online is either generic, contradictory, or
              motivated by someone trying to sell you something you don't need.
            </p>
            <p>
              We started Northbound to do this differently. Honest advice from
              the first call. Transparent pricing. Real expertise in the visas
              we specialise in — USA, UK, Schengen and Canada — and the
              integrity to refer you elsewhere if your case sits outside our
              core work.
            </p>
            <p className="text-gold font-medium font-display text-2xl italic">
              "Visas done right. By people who care whether you actually get
              one."
            </p>
            <p>
              Our clients are South African families visiting relatives abroad,
              first-time tourists planning the trip of a lifetime, professionals
              attending conferences, students applying for short courses, and
              applicants who've been refused before and need someone to take
              their second chance seriously. We treat every file like our own.
            </p>
          </div>
        </Reveal>
      </section>

      {/* VALUES */}
      <section className="py-16 bg-navy-light/30 border-y border-gold/15">
        <div className="max-w-7xl mx-auto px-6">
          <Reveal>
            <div className="text-center mb-14">
              <span className="gold-divider mb-6">Our Values</span>
              <h2 className="font-display text-4xl md:text-5xl font-bold mt-6">
                What we <span className="gold-text italic">stand for.</span>
              </h2>
            </div>
          </Reveal>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {TRUST_POINTS.map((t, i) => (
              <Reveal key={t.title} delay={i * 100}>
                <div className="bg-navy border border-gold/20 rounded-lg p-7 h-full hover:border-gold/50 transition-colors">
                  <div className="w-10 h-10 rounded-full bg-gold/10 border border-gold/40 flex items-center justify-center mb-5">
                    <span className="font-display text-gold font-bold text-lg">
                      {i + 1}
                    </span>
                  </div>
                  <h3 className="font-display text-xl font-bold mb-3 text-gold">
                    {t.title}
                  </h3>
                  <p className="text-white/60 text-sm leading-relaxed">{t.body}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* PROMISE */}
      <section className="py-24 max-w-4xl mx-auto px-6">
        <Reveal>
          <div className="bg-navy-light/40 border-2 border-gold/40 rounded-lg p-10 md:p-14">
            <h2 className="font-display text-3xl md:text-4xl font-bold mb-6 text-center">
              The Northbound <span className="gold-text italic">Promise.</span>
            </h2>
            <ul className="space-y-4 text-white/70">
              <li className="flex items-start gap-4">
                <span className="text-gold text-xl mt-0.5">★</span>
                <span>
                  <strong className="text-white">We will not guarantee approval.</strong>{' '}
                  Visa outcomes are decided by consular officers, not agents. Anyone
                  who guarantees otherwise is committing fraud.
                </span>
              </li>
              <li className="flex items-start gap-4">
                <span className="text-gold text-xl mt-0.5">★</span>
                <span>
                  <strong className="text-white">We will tell you the truth about your chances.</strong>{' '}
                  If we think your application is weak, we'll tell you what to
                  strengthen first — even if that means turning down your file.
                </span>
              </li>
              <li className="flex items-start gap-4">
                <span className="text-gold text-xl mt-0.5">★</span>
                <span>
                  <strong className="text-white">Your data stays private.</strong>{' '}
                  We are POPIA-compliant. We do not sell, share, or disclose
                  client information. Ever.
                </span>
              </li>
              <li className="flex items-start gap-4">
                <span className="text-gold text-xl mt-0.5">★</span>
                <span>
                  <strong className="text-white">You'll always know what's happening.</strong>{' '}
                  Clear updates, defined timelines, and a real person on
                  WhatsApp when you have a question.
                </span>
              </li>
            </ul>
          </div>
        </Reveal>
      </section>

      {/* CTA */}
      <section className="pb-24 text-center max-w-3xl mx-auto px-6">
        <Reveal>
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-6">
            Ready to begin?
          </h2>
          <p className="text-white/70 mb-8">
            Send us a WhatsApp message or fill in our contact form. No obligation, no pressure.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <a
              href={`https://wa.me/${SITE.whatsapp}`}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-emerald"
            >
              WhatsApp Us
            </a>
            <Link href="/contact" className="btn-gold">
              Contact Form
            </Link>
          </div>
        </Reveal>
      </section>
    </>
  );
}

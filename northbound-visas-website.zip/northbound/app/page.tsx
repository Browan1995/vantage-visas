import Link from 'next/link';
import Image from 'next/image';
import { SITE, SERVICES, TRUST_POINTS } from '@/lib/config';
import Reveal from '@/components/Reveal';
import ContactForm from '@/components/ContactForm';

export default function HomePage() {
  const waLink = `https://wa.me/${SITE.whatsapp}?text=${encodeURIComponent(
    "Hi! I'd like to start a visa application with Northbound Visas."
  )}`;

  return (
    <>
      {/* HERO */}
      <section className="relative min-h-screen flex items-center stars-bg overflow-hidden pt-24">
        <div
          className="absolute inset-0 opacity-30"
          style={{
            backgroundImage:
              'url(https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=1800&q=80)',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-navy/85 via-navy/90 to-navy" />

        <div className="relative max-w-7xl mx-auto px-6 py-20 w-full">
          <div className="max-w-3xl">
            <Reveal>
              <span className="gold-divider mb-8">South Africa · Worldwide</span>
            </Reveal>
            <Reveal delay={150}>
              <h1 className="font-display text-5xl md:text-7xl lg:text-8xl font-bold leading-[1.05] mb-8">
                Helping
                <br />
                <span className="gold-text italic">South Africans</span>
                <br />
                go further.
              </h1>
            </Reveal>
            <Reveal delay={300}>
              <p className="text-lg md:text-xl text-white/70 max-w-2xl mb-10 leading-relaxed">
                Specialist visa consultancy for the United States, United
                Kingdom, Schengen and Canada — with refusal-recovery expertise
                and care at every step of the journey.
              </p>
            </Reveal>
            <Reveal delay={450}>
              <div className="flex flex-wrap gap-4">
                <a href={waLink} target="_blank" rel="noopener noreferrer" className="btn-emerald">
                  <WhatsAppIcon /> Apply via WhatsApp
                </a>
                <Link href="/services" className="btn-gold">
                  View Services & Pricing
                </Link>
              </div>
            </Reveal>
          </div>
        </div>

        {/* Bottom fade */}
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-navy to-transparent pointer-events-none" />
      </section>

      {/* TRUST STRIP */}
      <section className="bg-navy-light/40 border-y border-gold/20 py-8">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-wrap items-center justify-center gap-x-12 gap-y-4 text-white/60 text-sm">
            <span>★ Honest Advice</span>
            <span className="text-gold/40">|</span>
            <span>POPIA Compliant</span>
            <span className="text-gold/40">|</span>
            <span>South African Owned</span>
            <span className="text-gold/40">|</span>
            <span>Refusal-Recovery Specialists</span>
          </div>
        </div>
      </section>

      {/* SERVICES PREVIEW */}
      <section className="py-24 max-w-7xl mx-auto px-6">
        <Reveal>
          <div className="text-center mb-16">
            <span className="gold-divider mb-6">Our Services</span>
            <h2 className="font-display text-4xl md:text-6xl font-bold mt-6 mb-4">
              Visas done <span className="gold-text italic">right.</span>
            </h2>
            <p className="text-white/60 max-w-2xl mx-auto">
              Five specialist visa pathways. Transparent pricing. End-to-end
              preparation from your first call to your interview day.
            </p>
          </div>
        </Reveal>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {SERVICES.map((s, i) => (
            <Reveal key={s.id} delay={i * 80}>
              <Link
                href={`/services#${s.id}`}
                className="block group bg-navy-light/50 border border-gold/15 hover:border-gold/50 rounded-lg overflow-hidden card-lift h-full"
              >
                <div className="aspect-[16/10] relative overflow-hidden">
                  <img
                    src={s.image}
                    alt={s.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy via-navy/40 to-transparent" />
                  <div className="absolute bottom-4 right-4 bg-gold text-navy px-3 py-1.5 rounded text-sm font-bold">
                    {s.price}
                  </div>
                </div>
                <div className="p-6">
                  <div className="text-xs text-gold uppercase tracking-widest mb-2">
                    {s.subtitle}
                  </div>
                  <h3 className="font-display text-2xl font-bold mb-2 group-hover:text-gold transition-colors">
                    {s.title}
                  </h3>
                  <p className="text-white/60 text-sm leading-relaxed">
                    {s.description}
                  </p>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      {/* WHY US */}
      <section className="py-24 bg-navy-light/30 border-y border-gold/15">
        <div className="max-w-7xl mx-auto px-6">
          <Reveal>
            <div className="text-center mb-16">
              <span className="gold-divider mb-6">Why Northbound</span>
              <h2 className="font-display text-4xl md:text-6xl font-bold mt-6">
                Built on <span className="gold-text italic">trust.</span>
              </h2>
            </div>
          </Reveal>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {TRUST_POINTS.map((t, i) => (
              <Reveal key={t.title} delay={i * 100}>
                <div className="bg-navy border border-gold/20 rounded-lg p-7 h-full hover:border-gold/50 transition-colors">
                  <div className="w-10 h-10 rounded-full bg-gold/10 border border-gold/40 flex items-center justify-center mb-5">
                    <span className="font-display text-gold font-bold text-lg">
                      {i + 1}
                    </span>
                  </div>
                  <h3 className="font-display text-xl font-bold mb-3 text-gold">
                    {t.title}
                  </h3>
                  <p className="text-white/60 text-sm leading-relaxed">{t.body}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* QUICK START FORM */}
      <section className="py-24 max-w-4xl mx-auto px-6">
        <Reveal>
          <div className="text-center mb-12">
            <span className="gold-divider mb-6">Get Started</span>
            <h2 className="font-display text-4xl md:text-5xl font-bold mt-6 mb-4">
              Start your <span className="gold-text italic">application.</span>
            </h2>
            <p className="text-white/60">
              Fill in the form below or message us on WhatsApp — we respond
              within 24 hours.
            </p>
          </div>
        </Reveal>
        <Reveal delay={150}>
          <ContactForm />
        </Reveal>
      </section>
    </>
  );
}

function WhatsAppIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
    </svg>
  );
}

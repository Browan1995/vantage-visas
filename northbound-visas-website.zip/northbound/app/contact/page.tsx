import { SITE } from '@/lib/config';
import Reveal from '@/components/Reveal';
import ContactForm from '@/components/ContactForm';

export const metadata = {
  title: 'Contact — Northbound Visas',
  description: 'Get in touch with Northbound Visas for your visa application.',
};

export default function ContactPage() {
  return (
    <>
      {/* HERO */}
      <section className="relative pt-40 pb-16 stars-bg">
        <div className="max-w-7xl mx-auto px-6">
          <Reveal>
            <span className="gold-divider mb-6">Get in Touch</span>
            <h1 className="font-display text-5xl md:text-7xl font-bold mt-6 mb-6 max-w-4xl">
              Let's start your <span className="gold-text italic">journey.</span>
            </h1>
            <p className="text-white/70 text-lg max-w-2xl">
              Reach out by WhatsApp, email, or the form below. We respond
              within 24 hours, every working day.
            </p>
          </Reveal>
        </div>
      </section>

      {/* CONTACT GRID */}
      <section className="pb-24 max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-3 gap-6 mb-12">
          <Reveal delay={0}>
            <a
              href={`https://wa.me/${SITE.whatsapp}`}
              target="_blank"
              rel="noopener noreferrer"
              className="block bg-emerald/10 border border-emerald/40 hover:border-emerald rounded-lg p-8 text-center transition-colors h-full card-lift"
            >
              <div className="w-14 h-14 bg-emerald rounded-full flex items-center justify-center mx-auto mb-4">
                <svg width="26" height="26" viewBox="0 0 24 24" fill="white">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                </svg>
              </div>
              <div className="text-xs uppercase tracking-widest text-emerald font-bold mb-2">
                Fastest Response
              </div>
              <h3 className="font-display text-2xl font-bold mb-2">WhatsApp</h3>
              <p className="text-white/70 text-sm">{SITE.whatsappDisplay}</p>
            </a>
          </Reveal>

          <Reveal delay={100}>
            <a
              href={`mailto:${SITE.email}`}
              className="block bg-navy-light/50 border border-gold/30 hover:border-gold rounded-lg p-8 text-center transition-colors h-full card-lift"
            >
              <div className="w-14 h-14 bg-gold/15 border border-gold/50 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#C9A961" strokeWidth="2">
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                  <polyline points="22,6 12,13 2,6" />
                </svg>
              </div>
              <div className="text-xs uppercase tracking-widest text-gold font-bold mb-2">
                Send a Message
              </div>
              <h3 className="font-display text-2xl font-bold mb-2">Email</h3>
              <p className="text-white/70 text-sm break-all">{SITE.email}</p>
            </a>
          </Reveal>

          <Reveal delay={200}>
            <div className="bg-navy-light/50 border border-gold/30 rounded-lg p-8 text-center h-full">
              <div className="w-14 h-14 bg-gold/15 border border-gold/50 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#C9A961" strokeWidth="2">
                  <circle cx="12" cy="12" r="10" />
                  <polyline points="12,6 12,12 16,14" />
                </svg>
              </div>
              <div className="text-xs uppercase tracking-widest text-gold font-bold mb-2">
                Response Time
              </div>
              <h3 className="font-display text-2xl font-bold mb-2">Within 24 Hours</h3>
              <p className="text-white/70 text-sm">Every working day</p>
            </div>
          </Reveal>
        </div>

        {/* FORM */}
        <Reveal>
          <div className="max-w-3xl mx-auto">
            <h2 className="font-display text-3xl font-bold text-center mb-3">
              Or fill in the <span className="gold-text italic">form below.</span>
            </h2>
            <p className="text-white/60 text-center mb-10">
              Tell us about your trip and we'll be in touch within a working day.
            </p>
            <ContactForm />
          </div>
        </Reveal>
      </section>
    </>
  );
}

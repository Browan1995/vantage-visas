import { SITE } from '@/lib/config';
import Reveal from '@/components/Reveal';

export const metadata = {
  title: 'Document Services — Northbound Visas',
  description: 'Police clearances, apostilles and sworn translations for South African travellers.',
};

const SERVICES = [
  {
    title: 'Police Clearances',
    icon: '🛡',
    body: 'South African Police Service (SAPS) clearance certificates are required for many long-stay visas, work permits, residency applications, and emigration cases. We assist with the full application process — fingerprinting, submission, tracking, and collection — so you don\'t have to navigate the SAPS system alone.',
    points: [
      'SAPS PCC application & submission',
      'Fingerprint card preparation',
      'Application tracking',
      'Collection & courier to you',
      'Apostille add-on available',
    ],
  },
  {
    title: 'Apostille & Authentication',
    icon: '✦',
    body: 'Documents being used in another country often need to be authenticated through the Apostille Convention or via legalisation at the relevant embassy. We handle the DIRCO (Department of International Relations and Co-operation) process for South African documents — birth certificates, marriage certificates, police clearances, qualifications and more.',
    points: [
      'DIRCO apostille service',
      'Embassy legalisation where required',
      'Document collection from issuing authority',
      'High commission attestations',
      'End-to-end tracking',
    ],
  },
  {
    title: 'Sworn Translations',
    icon: '✍',
    body: 'Many visa authorities require non-English documents to be translated by a sworn translator. We work with accredited sworn translators registered with the South African High Court for translations into and from English, Afrikaans, French, German, Spanish, Portuguese, Dutch and other major languages.',
    points: [
      'High Court sworn translators',
      'All major European languages',
      'Birth, marriage, divorce certificates',
      'Academic transcripts & qualifications',
      'Court-admissible certifications',
    ],
  },
];

export default function DocumentServicesPage() {
  return (
    <>
      {/* HERO */}
      <section className="relative pt-40 pb-20 stars-bg">
        <div className="max-w-7xl mx-auto px-6">
          <Reveal>
            <span className="gold-divider mb-6">Document Services</span>
            <h1 className="font-display text-5xl md:text-7xl font-bold mt-6 mb-6 max-w-4xl">
              Paperwork, <span className="gold-text italic">handled.</span>
            </h1>
            <p className="text-white/70 text-lg max-w-2xl">
              Police clearances, apostilles, and sworn translations — the
              documents you need to travel, work, study, or settle abroad.
              Sourced, certified, and delivered to you.
            </p>
          </Reveal>
        </div>
      </section>

      {/* SERVICES */}
      <section className="pb-24 max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-3 gap-6">
          {SERVICES.map((s, i) => (
            <Reveal key={s.title} delay={i * 100}>
              <div className="bg-navy-light/50 border border-gold/20 hover:border-gold/50 rounded-lg p-8 h-full transition-colors card-lift">
                <div className="text-5xl text-gold mb-5">{s.icon}</div>
                <h2 className="font-display text-3xl font-bold mb-4 text-gold">
                  {s.title}
                </h2>
                <p className="text-white/70 leading-relaxed mb-6 text-sm">
                  {s.body}
                </p>
                <ul className="space-y-2 mb-8">
                  {s.points.map((p) => (
                    <li
                      key={p}
                      className="flex items-start gap-3 text-white/70 text-sm"
                    >
                      <span className="text-gold mt-0.5">✓</span>
                      {p}
                    </li>
                  ))}
                </ul>
                <a
                  href={`https://wa.me/${SITE.whatsapp}?text=${encodeURIComponent(
                    `Hi! I'd like a quote for ${s.title.toLowerCase()}.`
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-gold w-full justify-center text-sm"
                >
                  Request a Quote
                </a>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* PROCESS */}
      <section className="pb-24 max-w-4xl mx-auto px-6">
        <Reveal>
          <div className="bg-navy-light/40 border border-gold/30 rounded-lg p-10 text-center">
            <h3 className="font-display text-3xl font-bold mb-4">
              How it <span className="gold-text italic">works.</span>
            </h3>
            <p className="text-white/60 mb-8 max-w-2xl mx-auto">
              Send us a WhatsApp message describing what you need. We'll quote
              you, collect what's required, process the documents, and deliver
              them — all without you setting foot in a government office.
            </p>
            <a
              href={`https://wa.me/${SITE.whatsapp}?text=${encodeURIComponent(
                "Hi! I need help with document services."
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-emerald"
            >
              Start on WhatsApp
            </a>
          </div>
        </Reveal>
      </section>
    </>
  );
}

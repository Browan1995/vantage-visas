// Single source of truth for all site content. Edit here, redeploy.

export const SITE = {
  name: 'Northbound Visas',
  tagline: 'Helping South Africans go further.',
  description:
    'Specialist USA, UK, Schengen and Canada visa consultancy for South Africans. Honest advice. Careful preparation. Clear results.',
  whatsapp: '27794748331', // E.164, no + or spaces
  whatsappDisplay: '+27 79 474 8331',
  email: 'rowanvdmerwe@gmail.com',
  url: 'https://northboundvisas.co.za',
};

export const NAV = [
  { label: 'Home', href: '/' },
  { label: 'Services', href: '/services' },
  { label: 'H-2B Guide', href: '/h2b-guide' },
  { label: 'Documents', href: '/document-services' },
  { label: 'About', href: '/about' },
  { label: 'Contact', href: '/contact' },
];

export const SERVICES = [
  {
    id: 'usa-b1b2',
    title: 'USA B1/B2',
    subtitle: 'Tourist & Business Visa',
    price: 'R1 800',
    description:
      'Full DS-160 preparation, document review, interview coaching and ongoing support for the United States Tourist and Business visitor visa.',
    features: [
      'Complete DS-160 form preparation',
      'Document checklist & review',
      'Mock interview & coaching',
      'Embassy appointment booking',
      'WhatsApp support throughout',
    ],
    image:
      'https://images.unsplash.com/photo-1485738422979-f5c462d49f74?w=1200&q=80',
  },
  {
    id: 'usa-h2b',
    title: 'USA H-2B',
    subtitle: 'Specialised Worker Visa',
    price: 'R800',
    description:
      'Specialist guidance through the H-2B temporary non-agricultural worker process, from petition verification to consular interview.',
    features: [
      'I-797 petition verification',
      'DS-160 preparation',
      'Document compilation',
      'Interview preparation',
      'End-to-end case management',
    ],
    image:
      'https://images.unsplash.com/photo-1454496522488-7a8e488e8606?w=1200&q=80',
  },
  {
    id: 'uk',
    title: 'UK Standard Visitor',
    subtitle: 'Tourism, Family & Business',
    price: 'R2 050',
    description:
      'United Kingdom Standard Visitor visa preparation including online application, supporting documents and biometric appointment.',
    features: [
      'Online UKVI application',
      'Cover letter & supporting docs',
      'Financial evidence guidance',
      'Biometric appointment booking',
      'Application tracking',
    ],
    image:
      'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?w=1200&q=80',
  },
  {
    id: 'schengen',
    title: 'Schengen',
    subtitle: 'European Travel Visa',
    price: 'R2 050',
    description:
      'Schengen short-stay visa for tourism, business or family visits across 27 European countries. Filed at the consulate of your main destination.',
    features: [
      'Consulate selection guidance',
      'Application form completion',
      'Travel insurance compliance',
      'Itinerary & accommodation prep',
      'Appointment booking',
    ],
    image:
      'https://images.unsplash.com/photo-1499856871958-5b9627545d1a?w=1200&q=80',
  },
  {
    id: 'canada',
    title: 'Canada',
    subtitle: 'Visitor Visa (TRV)',
    price: 'R1 900',
    description:
      'Canadian Temporary Resident Visa preparation. Online application, biometric submission and supporting evidence package.',
    features: [
      'IRCC online application',
      'Biometric submission guidance',
      'Strong supporting docs',
      'Letter of explanation',
      'Status tracking',
    ],
    image:
      'https://images.unsplash.com/photo-1503614472-8c93d56e92ce?w=1200&q=80',
  },
];

export const STATS = [
  { number: 5, suffix: '+', label: 'Visa destinations' },
  { number: 100, suffix: '%', label: 'Honest advice' },
  { number: 24, suffix: 'h', label: 'Average response time' },
  { number: 1, suffix: '', label: 'Trusted partner for your journey' },
];

export const TRUST_POINTS = [
  {
    title: 'Honest from the first call',
    body: 'No guarantees of approval, no inflated promises. We tell you the truth about your chances before you spend a cent.',
  },
  {
    title: 'Built for South Africans',
    body: 'Local consultancy, local accountability, local pricing. We understand the South African applicant context and prepare your file accordingly.',
  },
  {
    title: 'Refusal-recovery specialists',
    body: 'Been refused before? We take second-chance applications seriously and rebuild your file with care.',
  },
  {
    title: 'POPIA compliant',
    body: 'Your personal information is handled under the Protection of Personal Information Act. Confidentiality is non-negotiable.',
  },
];

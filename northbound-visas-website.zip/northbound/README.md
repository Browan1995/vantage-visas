# Northbound Visas — Website

The official website for Northbound Visas, built with Next.js 14, Tailwind CSS, and deployed on Vercel.

**Live site:** _add your URL here once deployed_

---

## What's in the box

- ⚡ **Next.js 14** App Router (TypeScript)
- 🎨 **Tailwind CSS** with the Northbound navy + gold + emerald palette
- 📱 **Fully mobile-responsive**
- 💬 **WhatsApp integration** on every page (floating button + CTAs)
- 📧 **Contact form** that emails you submissions via Resend
- 🔍 **SEO-ready** with proper meta tags
- 🚀 **Optimised for Vercel** (zero-config deploy)

---

## File structure

```
northbound/
├── app/
│   ├── api/contact/route.ts       ← Contact form email handler
│   ├── about/page.tsx             ← About Us page
│   ├── contact/page.tsx           ← Contact page
│   ├── document-services/page.tsx ← Police clearances, apostilles, translations
│   ├── h2b-guide/page.tsx         ← H-2B visa guide
│   ├── services/page.tsx          ← Services & pricing
│   ├── globals.css                ← Global styles
│   ├── layout.tsx                 ← Root layout (navbar, footer)
│   └── page.tsx                   ← Home page
├── components/
│   ├── ContactForm.tsx
│   ├── Footer.tsx
│   ├── Navbar.tsx
│   ├── Reveal.tsx                 ← Scroll reveal animation
│   └── WhatsAppFloat.tsx          ← Floating WhatsApp button
├── lib/
│   └── config.ts                  ← ★ Edit this to change content & prices
├── public/
│   └── logo.jpeg                  ← Your Northbound logo
├── .env.example                   ← Copy to .env.local
├── next.config.js
├── package.json
├── tailwind.config.ts
└── tsconfig.json
```

---

## Quick start (local development)

You'll need [Node.js 18+](https://nodejs.org) installed.

```bash
# 1. Install dependencies
npm install

# 2. Copy environment variables
cp .env.example .env.local

# 3. Run the development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser. Edit any file and the page reloads automatically.

---

## How to push to GitHub

If you've never used GitHub before, this is the part to follow carefully.

### 1. Create a new repository on GitHub

1. Go to [github.com](https://github.com) and sign in (or sign up).
2. Click the **+** in the top-right and choose **New repository**.
3. Name it: `northbound-visas`
4. Set it to **Private** (recommended) or Public.
5. **Do NOT** tick "Add a README" — we already have one.
6. Click **Create repository**.

### 2. Push this code to GitHub

GitHub will show you commands. Open a terminal in this project folder and run:

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/northbound-visas.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your actual GitHub username.

If git asks you to log in, use a [Personal Access Token](https://github.com/settings/tokens) as your password — GitHub no longer accepts account passwords for command-line pushes.

---

## How to deploy on Vercel

### 1. Sign up

1. Go to [vercel.com](https://vercel.com).
2. Click **Sign Up** and choose **Continue with GitHub**.
3. Authorise Vercel to access your GitHub account.

### 2. Import the project

1. On the Vercel dashboard, click **Add New → Project**.
2. Find `northbound-visas` in the list and click **Import**.
3. Vercel will auto-detect Next.js. Leave all build settings as default.
4. **Before clicking Deploy**, expand **Environment Variables** and add the three variables below.

### 3. Set up environment variables (for the contact form to work)

You need a free Resend account to send emails from the contact form.

1. Go to [resend.com](https://resend.com) and sign up.
2. After signing in, go to **API Keys** and click **Create API Key**.
3. Copy the key (starts with `re_`).

Now in Vercel's "Environment Variables" section, add:

| Name | Value |
|---|---|
| `RESEND_API_KEY` | The key you just copied (`re_...`) |
| `CONTACT_TO_EMAIL` | `rowanvdmerwe@gmail.com` |
| `CONTACT_FROM_EMAIL` | `onboarding@resend.dev` (works for testing) |

4. Click **Deploy**.

Vercel will build and deploy the site in about 60 seconds. You'll get a free `.vercel.app` URL.

### 4. (Optional) Connect a custom domain

1. Buy `northboundvisas.co.za` from a domain registrar (e.g., domains.co.za, Afrihost, GoDaddy).
2. In your Vercel project, go to **Settings → Domains**.
3. Add `northboundvisas.co.za` and follow Vercel's DNS instructions.
4. Vercel will issue an SSL certificate automatically.

### 5. (Optional) Verify your sending domain in Resend

For production, replace `onboarding@resend.dev` with an address on your own domain (e.g. `noreply@northboundvisas.co.za`):

1. In Resend, go to **Domains** and add `northboundvisas.co.za`.
2. Add the DNS records Resend gives you to your domain registrar.
3. Once verified, update `CONTACT_FROM_EMAIL` in Vercel to `noreply@northboundvisas.co.za`.

This makes your form emails look fully professional and improves deliverability.

---

## How to update content

**Almost everything you'll want to change lives in one file: `lib/config.ts`.**

```ts
export const SITE = {
  name: 'Northbound Visas',
  tagline: 'Helping South Africans go further.',
  whatsapp: '27794748331',          // ← Your WhatsApp number
  whatsappDisplay: '+27 79 474 8331',
  email: 'rowanvdmerwe@gmail.com',  // ← Your email
  url: 'https://northboundvisas.co.za',
};

export const SERVICES = [
  {
    id: 'usa-b1b2',
    title: 'USA B1/B2',
    price: 'R1 800',                // ← Edit prices here
    // ...
  },
];
```

Change anything in this file, save, push to GitHub, and Vercel auto-deploys the new version within a minute.

### Updating images

Page hero images currently use Unsplash URLs (free, royalty-free). To use your own photos:

1. Drop your image into the `public/` folder (e.g. `public/hero-mountains.jpg`).
2. In the page file, replace the Unsplash URL with `/hero-mountains.jpg`.

---

## Common questions

**Q: How do I add a new page?**
Create a folder under `app/` with your page name (e.g. `app/blog/page.tsx`) and add the link to `NAV` in `lib/config.ts`.

**Q: The contact form says "Email service not configured."**
You haven't set the `RESEND_API_KEY` environment variable in Vercel. Go to your Vercel project → Settings → Environment Variables → add it → click "Redeploy" on the latest deployment.

**Q: Can I use a different email service?**
Yes. Open `app/api/contact/route.ts` and replace the Resend code with SendGrid, Postmark, Mailgun, or even an SMTP library. Or use [Formspree](https://formspree.io) — change the form `action` to your Formspree URL and delete the API route entirely.

**Q: How do I change the colour scheme?**
Edit `tailwind.config.ts` (the `colors` section) and `app/globals.css` (the `:root` CSS variables). Both need to match.

**Q: Will this work on mobile?**
Yes — every page is fully responsive and tested down to 360px wide.

---

## Important legal notes

- The footer disclaimer about not guaranteeing visa outcomes is required for ethical practice and protects you legally. Don't remove it.
- The contact form includes a POPIA consent line. Keep this — it's South African data protection law.
- The form data is sent only to your email — it isn't stored anywhere by default. If you want a database/CRM, integrate with HubSpot, Zoho, or Airtable via the API route.

---

## Built with

- [Next.js 14](https://nextjs.org)
- [Tailwind CSS](https://tailwindcss.com)
- [Resend](https://resend.com) for transactional email
- [Unsplash](https://unsplash.com) for placeholder imagery

---

## Support

If you're stuck on deployment, the [Vercel docs](https://vercel.com/docs) and [Next.js docs](https://nextjs.org/docs) are excellent. Most issues are environment variable typos or missing dependencies.

© Northbound Visas. Built with care.

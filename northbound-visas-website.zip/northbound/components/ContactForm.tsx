'use client';

import { useState } from 'react';
import { SERVICES } from '@/lib/config';

export default function ContactForm() {
  const [status, setStatus] = useState<'idle' | 'sending' | 'sent' | 'error'>(
    'idle'
  );
  const [errorMsg, setErrorMsg] = useState('');

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setStatus('sending');
    setErrorMsg('');

    const fd = new FormData(e.currentTarget);
    const payload = {
      name: fd.get('name'),
      phone: fd.get('phone'),
      email: fd.get('email'),
      destination: fd.get('destination'),
      message: fd.get('message'),
    };

    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || 'Failed to send');
      }
      setStatus('sent');
    } catch (err: any) {
      setStatus('error');
      setErrorMsg(err.message || 'Something went wrong');
    }
  }

  if (status === 'sent') {
    return (
      <div className="bg-navy-light/50 border-2 border-gold/40 rounded-lg p-12 text-center">
        <div className="font-display text-3xl font-bold gold-text mb-4">
          Thank you.
        </div>
        <p className="text-white/70">
          Your message is on its way. We'll respond within 24 hours.
        </p>
      </div>
    );
  }

  return (
    <form
      onSubmit={onSubmit}
      className="bg-navy-light/50 border border-gold/30 rounded-lg p-8 md:p-10 space-y-5"
    >
      <div className="grid md:grid-cols-2 gap-5">
        <Field label="Full Name" name="name" required />
        <Field label="Phone Number" name="phone" type="tel" required />
      </div>
      <Field label="Email Address" name="email" type="email" required />
      <div>
        <label className="block text-xs uppercase tracking-widest text-gold font-bold mb-2">
          Destination
        </label>
        <select
          name="destination"
          required
          className="w-full bg-navy border border-gold/30 rounded px-4 py-3 text-white focus:outline-none focus:border-gold transition-colors"
        >
          <option value="">Select destination</option>
          {SERVICES.map((s) => (
            <option key={s.id} value={s.title}>
              {s.title}
            </option>
          ))}
          <option value="Other">Other / Not sure</option>
        </select>
      </div>
      <div>
        <label className="block text-xs uppercase tracking-widest text-gold font-bold mb-2">
          Message <span className="text-white/40 normal-case">(optional)</span>
        </label>
        <textarea
          name="message"
          rows={4}
          placeholder="Tell us briefly about your trip and any visa history..."
          className="w-full bg-navy border border-gold/30 rounded px-4 py-3 text-white focus:outline-none focus:border-gold transition-colors resize-y"
        />
      </div>
      <button
        type="submit"
        disabled={status === 'sending'}
        className="btn-emerald w-full justify-center text-base py-4 disabled:opacity-60"
      >
        {status === 'sending' ? 'Sending...' : 'Send Application'}
      </button>
      {status === 'error' && (
        <p className="text-red-400 text-sm text-center">{errorMsg}</p>
      )}
      <p className="text-xs text-white/40 text-center">
        By submitting, you consent to Northbound Visas processing your personal
        information under POPIA for the purpose of preparing your visa
        consultation.
      </p>
    </form>
  );
}

function Field({
  label,
  name,
  type = 'text',
  required = false,
}: {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label className="block text-xs uppercase tracking-widest text-gold font-bold mb-2">
        {label} {required && <span className="text-emerald">*</span>}
      </label>
      <input
        type={type}
        name={name}
        required={required}
        className="w-full bg-navy border border-gold/30 rounded px-4 py-3 text-white focus:outline-none focus:border-gold transition-colors"
      />
    </div>
  );
}

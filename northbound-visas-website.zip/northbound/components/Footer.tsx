import Link from 'next/link';
import Image from 'next/image';
import { SITE, NAV } from '@/lib/config';

export default function Footer() {
  return (
    <footer className="bg-navy-dark border-t border-gold/20 mt-20">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid md:grid-cols-4 gap-12">
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-5">
              <div className="bg-cream rounded p-1.5 border border-gold/40">
                <Image src="/logo.jpeg" alt={SITE.name} width={48} height={48} className="rounded" />
              </div>
              <div>
                <div className="font-display font-bold text-xl">Northbound</div>
                <div className="text-[10px] tracking-[2px] text-gold uppercase">
                  Visa Agency
                </div>
              </div>
            </div>
            <p className="text-white/60 text-sm leading-relaxed max-w-md">
              Specialist USA, UK, Schengen and Canada visa consultancy for South
              Africans — and many other destinations on request. Honest advice.
              Careful preparation. Clear results.
            </p>
            <div className="mt-6 text-xs text-gold tracking-wider uppercase">
              {SITE.tagline}
            </div>
          </div>

          <div>
            <h4 className="text-gold text-xs uppercase tracking-widest font-bold mb-4">
              Navigate
            </h4>
            <ul className="space-y-2.5">
              {NAV.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className="text-white/60 hover:text-gold text-sm transition-colors"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-gold text-xs uppercase tracking-widest font-bold mb-4">
              Contact
            </h4>
            <ul className="space-y-3 text-sm text-white/60">
              <li>
                <a
                  href={`https://wa.me/${SITE.whatsapp}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-gold transition-colors block"
                >
                  WhatsApp<br />
                  <span className="text-white/80">{SITE.whatsappDisplay}</span>
                </a>
              </li>
              <li>
                <a
                  href={`mailto:${SITE.email}`}
                  className="hover:text-gold transition-colors block break-all"
                >
                  {SITE.email}
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 mt-12 pt-8 flex flex-col md:flex-row justify-between gap-4">
          <p className="text-xs text-white/40">
            © {new Date().getFullYear()} {SITE.name}. All rights reserved.
          </p>
          <p className="text-xs text-white/40">
            POPIA compliant · Cannot guarantee visa outcomes · Outcomes decided by issuing authority
          </p>
        </div>
      </div>
    </footer>
  );
}
